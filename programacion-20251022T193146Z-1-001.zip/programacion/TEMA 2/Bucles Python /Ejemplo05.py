nombres = ["David", "Pepito", "Manolito", "Julita", "Andreita"]

for i in range(0, len(nombres)):
	print(nombres[i])


