# Mostrar los multiplos de 3 comprendidos entre 1 y 3000
# Con bucle for

#for i in range(1, 3001):
#	if i%3 == 0:
#		print(i)

#for i in range(1, 1001):
#	print(i*3)

for i in range(3, 3001, 3):
	print(i)
