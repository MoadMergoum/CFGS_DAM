# Un programa que pida un numero entero y compruebe si es par o impar y que repita este proceso hasta que se introduzca el 0, que finalizara
numero = -1
while numero != 0:
	numero = int(input("Introduce un numero entero: "))

	if numero%2 == 0:
		print("El numero " + str(numero) + " es par")
	else:
		print("El numero " + str(numero) + " es impar")

print("\nFin del programa")
