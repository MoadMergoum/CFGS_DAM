# Pide al usuario un numero entero y muestra la tabla de multiplicar de ese numero
num = int(input("Indica la tabla de multiplicar: "))

for i in range(1, 11):
	print(str(num) + " x " + str(i) + " = " + str(num*i))
