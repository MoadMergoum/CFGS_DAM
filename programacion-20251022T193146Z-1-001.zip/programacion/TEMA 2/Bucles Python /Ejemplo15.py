altura = int(input("Indica la altura en líneas del triángulo: "))

for i in range(1, altura + 1):
    texto = ""

  
    for j in range(altura - i):
        texto += " "

    
    for k in range(i):
        texto += "*"

    print(texto)

print("\nFin del programa")

