numeros = [1, 2, 3, 4, 5]
texto = ""

for i in range(len(numeros)):
    for j in range(numeros[i]):
        texto += str(numeros[i]) + " "
    texto += "\n"

print(texto)
print("\nFin del programa")

