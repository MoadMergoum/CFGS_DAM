numeros = [6, 5, 0, 1, 8]

print("\nLongitud del array: " + str( len(numeros) ))

texto = "\nNumeros: "

for i in range( len(numeros) ):
	texto += str(numeros[i]) + " "

print(texto)
