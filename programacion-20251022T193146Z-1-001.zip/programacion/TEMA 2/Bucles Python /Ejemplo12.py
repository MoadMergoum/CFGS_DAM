altura = int(input("Indica la altura en lineas del triangulo: "))
texto = ""

for i in range(altura, -1, -1):
    for j in range(i + 1):
        texto += "*"
    texto += "\n"

print(texto)
print("\nFin del programa")

