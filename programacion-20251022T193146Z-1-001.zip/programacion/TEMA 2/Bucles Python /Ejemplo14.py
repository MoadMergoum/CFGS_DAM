altura = int(input("Indica la altura en lineas del triangulo: "))
texto = ""

for i in range(altura + 1):
    for j in range(1, altura - i + 1):
        texto += " "
    for j in range(i + 1):
        texto += "*"
    texto += "\n"

print(texto)
print("\nFin del programa")

