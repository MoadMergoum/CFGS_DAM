# Pedir al usuario 10 numeros enteros y guardarlos en un array
# Luego se muestran en el mismo orden que se han introducido
# Luego se ordenan de menor a mayor
# Por ultimo se muestran ya ordenados

# Parte 1
print("Introduce 10 numeros")
numeros = []
for i in range(1, 11):
	num = int(input(str(i) + "º numero: "))
	numeros.append(num)

# Parte 2
print("\nNumeros introducidos")
texto = ""
for num in numeros:
	texto += str(num) + " "
print(texto)

# Parte 3
for i in range(len(numeros)):
	for j in range(i, len(numeros)):
		if numeros[i] > numeros[j]:
			aux = numeros[i]
			numeros[i] = numeros[j]
			numeros[j] = aux
'''
for i in range(1, len(numeros)):
	for j in range(0, len(numeros)-i):
		if numeros[j] > numeros[j+1]:
			aux = numeros[j]
			numeros[j] = numeros[j+1]
			numeros[j+1] = aux
'''

# Parte 4
print("\nNumeros ordenados")
texto = ""
for num in numeros:
	texto += str(num) + " "
print(texto)

print("\nFin del programa")

