numeros = []

print("Longitud del array: " + str( len(numeros) ))
print("Array: " + str(numeros))

numeros.append(3)
print("\nLongitud del array: " + str( len(numeros) ))
print("Array: " + str(numeros))

numeros.append(6)
print("\nLongitud del array: " + str( len(numeros) ))
print("Array: " + str(numeros))

numeros.append(0)
print("\nLongitud del array: " + str( len(numeros) ))
print("Array: " + str(numeros))

numeros.append(7)
print("\nLongitud del array: " + str( len(numeros) ))
print("Array: " + str(numeros))

print("\nFin del programa")
