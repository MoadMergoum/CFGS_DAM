# Pedir al usuario cuantos numeros quiere y despues, pedir al usuario esa cantidad de numeros y guardarlos en un array.
#Al final, mostrar los numeros en linea separados por espacios
numeros = []

cantidad = int(input("Cuantos numeros quieres?: "))

# Introducir datos con el metodo .append()
for i in range(0, cantidad):
	num = int(input(str(i+1) + "º Numero: "))
	numeros.append(num)

print("\nNumeros introducidos\n")

texto = "-----------\n"
for num in numeros:
	texto += str(num) + " "
texto += "\n-----------"

print(texto)

print("\nFin de programa")
