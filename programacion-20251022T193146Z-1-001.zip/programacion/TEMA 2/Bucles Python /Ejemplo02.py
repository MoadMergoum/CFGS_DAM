numeros = [6, 5, 0, 1, 8]

# Version "foreach"
for num in numeros:
	print("Numero: " + str(num))

texto = "\nNumeros: "
for num in numeros:
	texto += str(num) + " "

print(texto)
