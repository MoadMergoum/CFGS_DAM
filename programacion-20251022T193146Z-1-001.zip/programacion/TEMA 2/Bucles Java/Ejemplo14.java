import java.util.Scanner;

public class Ejemplo14 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int opcion;

		do {
			System.out.print("Menu\n1 - Cargar fichero\n2 - Escribir datos\n3 - Ver conexiones\n0 - Cancelar\n\nSelecciona una opcion: ");
			opcion = Integer.parseInt(teclado.nextLine());
		} while(opcion < 0 || opcion > 3);

		System.out.println("Opcion elegida: " + opcion);
	}
}




