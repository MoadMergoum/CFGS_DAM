import java.util.Scanner;

public class Ejemplo18 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int[][] numeros = {
			{8, 7, 2, 4},
			{6, 7, 0, 3},
			{0, 1, 3, 8},
			{3, 7, 1, 9},
			{8, 5, 3, 1}
		};

		for(int i = 0; i < numeros.length; i++) {

			for(int j = 0; j < numeros[i].length; j++) {
				System.out.print(numeros[i][j] + " ");
			}

			System.out.println();
		}

		System.out.println("\nFin del programa");
	}
}


