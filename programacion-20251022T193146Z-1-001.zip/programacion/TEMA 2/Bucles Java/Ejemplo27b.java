import java.util.Scanner;

public class Ejemplo27b {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Indica la altura en lineas del triangulo: ");
        int altura = Integer.parseInt(teclado.nextLine());
        String texto = "";

        int asteriscos = 2 * altura - 1; // Máximo número de asteriscos en la primera línea

        for (int i = 0; i < altura; i++) {
            // Imprimir espacios al inicio de cada línea
            for (int j = 0; j < i; j++) {
                texto += " ";
            }

            // Imprimir asteriscos
            for (int j = 0; j < asteriscos; j++) {
                texto += "*";
            }

            texto += "\n";
            asteriscos -= 2; // Disminuir el número de asteriscos en cada línea
        }

        System.out.println(texto);
        System.out.println("\nFin del programa");
    }
}

