import java.util.Scanner;

public class Ejemplo20 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Pedir al usuario la cantidad de filas y columnas de la matriz para darle ese tamaño
		System.out.print("Numero de filas: ");
		int filas = Integer.parseInt(teclado.nextLine());
		System.out.print("Numero de columnas: ");
		int columnas = Integer.parseInt(teclado.nextLine());

		int[][] numeros = new int[filas][columnas];

		// Pedir los numeros
		for(int i = 0; i < numeros.length; i++) {
			System.out.println("\n" + (i+1) + "º array interno");
			for(int j = 0; j < numeros[i].length; j++) {
				System.out.print((j+1) + "º numero: ");

				numeros[i][j] = Integer.parseInt(teclado.nextLine());

			}
		}

		System.out.println("\nNumeros en la matriz");

		for(int i = 0; i < numeros.length; i++) {

			for(int j = 0; j < numeros[i].length; j++) {
				System.out.print(numeros[i][j] + " ");
			}

			System.out.println();
		}

		System.out.println("\nFin del programa");
	}
}


