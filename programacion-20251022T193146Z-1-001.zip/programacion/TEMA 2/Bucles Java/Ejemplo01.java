public class Ejemplo01 {
	public static void main(String[] args) {
		System.out.println("Inicio del programa");

		System.out.println("Me llamo David");
		System.out.println("Me llamo David");
		System.out.println("Me llamo David");
		System.out.println("Me llamo David");
		System.out.println("Me llamo David");

		System.out.println("Fin del programa");
	}
}
