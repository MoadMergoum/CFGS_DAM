import java.util.Scanner;

public class Ejemplo27 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Indica la altura en lineas del triangulo: ");
        int altura = Integer.parseInt(teclado.nextLine());
        String texto = "";

        int asteriscos = 1;
        for (int i = 1; i <= altura; i++) {
            // Imprimir espacios
            for (int j = 1; j <= (altura - i); j++) {
                texto += " ";
            }

            // Imprimir asteriscos
            for (int j = 1; j <= asteriscos; j++) {
                texto += "*";
            }

            texto += "\n";
            asteriscos += 2; // Incrementar número de asteriscos en cada fila
        }

        System.out.println(texto);
        System.out.println("\nFin del programa");
    }
}

