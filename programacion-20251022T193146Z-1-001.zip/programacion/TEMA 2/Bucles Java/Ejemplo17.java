import java.util.Scanner;

public class Ejemplo17 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Doble bucle for

		for(int a = 1; a <= 10; a++) {
			System.out.println("\nTabla de multiplicar del " + a);

			for(int b = 1; b <= 10; b++) {
				System.out.println(a + " x " + b + " = " + (a*b));
			}
		}

		System.out.println("\nFin del programa");
	}
}


