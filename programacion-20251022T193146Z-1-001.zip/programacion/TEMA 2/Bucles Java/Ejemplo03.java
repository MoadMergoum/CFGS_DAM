import java.util.Scanner;

public class Ejemplo03 {
	public static void main(String[] args) {
		System.out.println("Inicio del programa");
		Scanner teclado = new Scanner(System.in);

		System.out.print("Introduce un numero para mostrar la tabla de multiplicar: ");
		int num = Integer.parseInt(teclado.nextLine());

		for(int i = 1; i <= 10; i++) {
			System.out.println(num + " x " + i + " = " + (num*i));
		}

		System.out.println("Fin del programa");
	}
}
