import java.util.Scanner;

public class Ejemplo22b {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int[] numeros = {4, 9, 5, 3, 7};

		for(int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i] + " ");
		}

		// Algoritmo Burbuja (version David)
		for(int i = 0; i < numeros.length; i++) {
			for(int j = i; j < numeros.length; j++) {
				if(numeros[i] > numeros[j]) {
					int aux = numeros[i];
					numeros[i] = numeros[j];
					numeros[j] = aux;
				}
			}
		}

		System.out.println("\nNumeros ordenados");
		for(int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i] + " ");
		}

		System.out.println("\nFin del programa");
	}
}


