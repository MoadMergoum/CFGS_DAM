public class Ejemplo05 {
	public static void main(String[] args) {
		// Declarar array de enteros
		int[] numeros = {2, 34, 8, 56, 7, 1, 9};

		System.out.println("Cantidad de elementos: " + numeros.length);

		// Condiciones iguales
		// i <= numeros.length-1
		// i < numeros.length

		for(int i = 0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}
	}
}
