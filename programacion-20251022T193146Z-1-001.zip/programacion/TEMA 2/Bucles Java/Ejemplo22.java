import java.util.Scanner;

public class Ejemplo22 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int[] numeros = {4, 9, 5, 3, 7};

		for(int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i] + " ");
		}

		// Algoritmo Burbuja (BubbleSort)
		for(int i = 1; i < numeros.length; i++) {
			for(int j = 0; j < numeros.length-i; j++) {
				if(numeros[j] > numeros[j+1]) {
					int aux = numeros[j];
					numeros[j] = numeros[j+1];
					numeros[j+1] = aux;
				}
			}
		}

		System.out.println("\nNumeros ordenados");
		for(int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i] + " ");
		}

		System.out.println("\nFin del programa");
	}
}


