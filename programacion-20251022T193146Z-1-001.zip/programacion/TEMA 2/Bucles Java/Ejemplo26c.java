import java.util.Scanner;

public class Ejemplo26c{
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

		System.out.print("Indica la altura en lineas del triangulo: ");


	
		int altura = Integer.parseInt(teclado.nextLine());
		String texto = "";

		for (int i = 0 ;i <= altura; i++) {
            for (int j = 1; j <= altura-i; j++) {
                texto +=  " ";
            }
			for (int j = 0; j <= i; j++) {
                texto +=  "*";
            }
            texto += "\n";
        }

		System.out.println(texto);
		System.out.println("\nFin del programa");
    }
}
