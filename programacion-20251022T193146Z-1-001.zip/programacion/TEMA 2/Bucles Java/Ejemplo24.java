import java.util.Scanner;

public class Ejemplo24 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		String[] nombres = {"Isabelita", "Quique", "Eugenio", "Eustaquio", "Alberto"};

		for(int i = 0; i < nombres.length; i++) {
			for(int j = i; j < nombres.length; j++) {
				if(nombres[i].compareToIgnoreCase(nombres[j]) > 0) {
					String aux = nombres[i];
					nombres[i] = nombres[j];
					nombres[j] = aux;
				}
			}
		}

		for(int i = 0; i < nombres.length; i++) {
			System.out.println(nombres[i]);
		}

		System.out.println("\nFin del programa");
	}
}


