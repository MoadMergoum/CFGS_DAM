import java.util.Scanner;

public class Ejemplo15 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		String opcion;

		do {
			System.out.print("Escribe el comando que quieres ejecutar o escribe 'Salir' para finalizar: ");
			opcion = teclado.nextLine();

			if(opcion.equalsIgnoreCase("crear")) {
				System.out.println("\nHas seleccionado CREAR\n");
			} else if(opcion.equalsIgnoreCase("copiar")) {
				System.out.println("\nHas seleccionado COPIAR\n");
			}

		} while(!opcion.equalsIgnoreCase("salir"));

		System.out.println("\nFin del programa");
	}
}




