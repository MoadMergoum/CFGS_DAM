import java.util.Scanner;

public class Ejemplo23 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Pedir al usuario 10 numeros enteros y luego que pregunte al usuario si quiere ordenarlos de forma ascendente o descendente, luego tiene que ordenarlos y mostrarlos por consola

		int[] numeros = new int[10];
		for(int i = 0; i < numeros.length; i++) {
			System.out.print((i+1) + "º numero: ");
			numeros[i] = Integer.parseInt(teclado.nextLine());
		}

		System.out.print("\nElige tipo de ordenacion\n1 - Ascendente\n2 - Descendente\nSelecciona opcion: ");
		int opcion = Integer.parseInt(teclado.nextLine());

		for(int i = 0; i < numeros.length; i++) {
			for(int j = i; j < numeros.length; j++) {
				if(	(opcion == 1 && numeros[i] > numeros[j])
				 || (opcion == 2 && numeros[i] < numeros[j]) ) {
					int aux = numeros[i];
					numeros[i] = numeros[j];
					numeros[j] = aux;
				}
			}
		}

		System.out.println("\nNumeros ordenados");
		for(int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i] + " ");
		}

		System.out.println("\nFin del programa");
	}
}


