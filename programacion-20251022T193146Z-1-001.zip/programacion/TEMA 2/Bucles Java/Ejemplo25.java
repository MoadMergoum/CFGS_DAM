import java.util.Scanner;

public class Ejemplo25 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int[] numeros = {1, 2, 3, 4, 5};
        String texto = "";

        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros[i]; j++) {
                texto += numeros[i] + " ";
            }
            texto += "\n";
        }

        System.out.println(texto);
        System.out.println("\nFin del programa");
    }
}

