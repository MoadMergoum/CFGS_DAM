import java.util.Scanner;

public class Ejemplo13 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		/*int contador = 0;
		while(true) {	
			System.out.println("Vuelta " + contador);
			contador++;
			if(contador == 1000000) {
				break;
			}	
		}*/

		int opcion;

		while(true) {
			System.out.print("Menu\n1 - Cargar fichero\n2 - Escribir datos\n3 - Ver conexiones\n0 - Cancelar\n\nSelecciona una opcion: ");
			opcion = Integer.parseInt(teclado.nextLine());
			if(opcion >= 0 && opcion <= 3) {
				break;
			}
			System.out.println("\n\nOpcion no valida\n\n");
		}

		System.out.println("Opcion elegida: " + opcion);
	}
}




