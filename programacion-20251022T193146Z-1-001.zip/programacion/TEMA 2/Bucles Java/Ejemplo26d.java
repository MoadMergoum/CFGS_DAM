import java.util.Scanner;

public class Ejemplo26d {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Indica la altura en líneas del triángulo: ");
        int altura = Integer.parseInt(teclado.nextLine());

        for (int i = 1; i <= altura; i++) {
            String texto = "";

            // Espacios en blanco
            for (int j = 1; j <= altura - i; j++) {
                texto += " ";
            }

            // Asteriscos
            for (int k = 1; k <= i; k++) {
                texto += "*";
            }

            System.out.println(texto);
        }

        System.out.println("\nFin del programa");
        teclado.close();
    }
}

