import java.util.Scanner;

public class Ejemplo07 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Pedir al usuario la cantidad de numeros que quiere y que el array tenga ese tamaño 💩️
		System.out.print("Indica la cantidad de numeros que quieres: ");
		int cantidad = Integer.parseInt(teclado.nextLine());

		// Array vacio de tamaño 5 elementos
		int[] numeros = new int[cantidad];

		for(int i = 0; i < numeros.length; i++) {
			System.out.print((i+1) + "º numero: ");
			numeros[i] = Integer.parseInt(teclado.nextLine());
		}

		System.out.println("\nNumeros en el array de enteros");

		for(int i = 0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}
	}
}








