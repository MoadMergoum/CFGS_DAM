import java.util.Scanner;

public class Ejemplo09 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		System.out.print("Introduce un texto: ");
		String texto = teclado.nextLine().trim();

		System.out.println("Longitud de la cadena: " + texto.length());

		// Recorrer la cadena como un array
		for(int i = 0; i < texto.length(); i++) {
			System.out.println(    texto.charAt(i)   );
		}
	}
}

