import java.util.Scanner;

public class Ejemplo23b {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		int[] numeros = new int[10];
		for(int i = 0; i < numeros.length; i++) {
			System.out.print((i+1) + "º numero: ");
			numeros[i] = Integer.parseInt(teclado.nextLine());
		}

		// Insistir al usuario en caso de que no haya seleccionado una ordenacion correctamente
		int opcion;
		do {
			System.out.print("\nElige tipo de ordenacion\n1 - Ascendente\n2 - Descendente\nSelecciona opcion: ");
			opcion = Integer.parseInt(teclado.nextLine());
			
			if(opcion < 1 || opcion > 2) {
				System.out.println("\nOPCION INCORRECTA. Intentelo de nuevo");
			}
			
		} while(opcion < 1 || opcion > 2);

		for(int i = 0; i < numeros.length; i++) {
			for(int j = i; j < numeros.length; j++) {
				if(	(opcion == 1 && numeros[i] > numeros[j])
				 || (opcion == 2 && numeros[i] < numeros[j]) ) {
					int aux = numeros[i];
					numeros[i] = numeros[j];
					numeros[j] = aux;
				}
			}
		}

		System.out.println("\nNumeros ordenados");
		for(int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i] + " ");
		}

		System.out.println("\nFin del programa");
	}
}


