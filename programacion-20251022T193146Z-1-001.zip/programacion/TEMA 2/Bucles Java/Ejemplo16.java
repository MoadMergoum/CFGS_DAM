import java.util.Scanner;

public class Ejemplo16 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		String[] nombres = {"David", "Manolito", "Antoñito", "Pepito", "Paulita"};
		
		System.out.println("\nBucle for normal");
		// Bucle "normal", "tradicional"
		for(int i = 0; i < nombres.length; i++) {
			System.out.println((i+1) + "º: " + nombres[i]);
		}

		System.out.println("\nBucle for-each");
		int i = 0;
		for(String nombre : nombres) {
			System.out.println((i+1) + "º: " + nombre);
			i++;
		}

		System.out.println("\nFin del programa");
	}
}


