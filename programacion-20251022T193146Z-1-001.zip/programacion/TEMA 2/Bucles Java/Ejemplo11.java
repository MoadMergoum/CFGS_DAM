import java.util.Scanner;

public class Ejemplo11 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		String texto = "Esto es una cadena";

		// Bucle while
		int i = 0;
		while(texto.charAt(i) != 'd') {
			System.out.print(texto.charAt(i));
			i++;
		}

		System.out.println("\nFinal del programa");
	}
}

