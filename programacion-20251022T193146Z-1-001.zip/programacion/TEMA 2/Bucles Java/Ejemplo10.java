import java.util.Scanner;

public class Ejemplo10 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		System.out.print("Introduce un texto: ");
		String texto = teclado.nextLine().trim();

		System.out.println("Longitud de la cadena: " + texto.length());

		// Recorrer la cadena como un array
		// Modificar el contenido del bucle para que muestre cada palabra en una linea distinta
		for(int i = 0; i < texto.length(); i++) {
			if(texto.charAt(i) != ' ') {
				System.out.print(    texto.charAt(i)   );
			} else {
				System.out.println();
			}

			if(i == texto.length()-1) {
				System.out.println();
			}
		}
	}
}

