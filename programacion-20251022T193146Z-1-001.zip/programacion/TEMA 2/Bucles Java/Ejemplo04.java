public class Ejemplo04 {
	public static void main(String[] args) {
		// Declarar array de enteros
		int[] numeros = {2, 34, 8, 56, 7, 1};

		System.out.println(numeros[0]);
		System.out.println(numeros[1]);
		System.out.println(numeros[2]);
		System.out.println(numeros[3]);
		System.out.println(numeros[4]);
		System.out.println(numeros[5]);
	}
}
