public class Ejemplo02 {
	public static void main(String[] args) {
		System.out.println("Inicio del programa");

		int contador = 1;
		// Incremento de variable el 1 unidad
		// Forma 1
		contador = contador + 1;
		// Forma 2
		contador += 1;
		// Forma 3
		contador++;

		for(int i = 1; i <= 5; i++) {
			System.out.println("Me llamo David");
		}

		System.out.println("Fin del programa");
	}
}
