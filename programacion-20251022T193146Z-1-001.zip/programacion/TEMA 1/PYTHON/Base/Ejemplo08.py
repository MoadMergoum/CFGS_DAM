valor1 = False
valor2 = True

if valor1:
    print("La primera es cierta")
elif valor2:
    print("La segunda es cierta")
elif not valor1 and not valor2:
    print("Ninguna es cierta")

