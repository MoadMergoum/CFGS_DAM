Edad = int(input("introduce un numero entero: "))

if Edad >=0 and Edad < 18:
	print("Menor de edad")
elif Edad >=18 :
	print("Edad de trabajar")
else:
	print("Edad no válida")

