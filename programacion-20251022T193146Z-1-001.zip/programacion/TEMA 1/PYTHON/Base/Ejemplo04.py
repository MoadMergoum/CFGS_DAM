print ("Introduce tu nombre")
nombre = input()
print("Tu nombre es " + nombre)

edad = input ("Introduce tu edad: ")
print("La edad es " + str(edad))
