cadena1= "coche"
cadena2= "Coche"

if cadena1.lower() == cadena2.lower():
    print("SON IGUALES")
else:
    print("SON DISTINTOS")
