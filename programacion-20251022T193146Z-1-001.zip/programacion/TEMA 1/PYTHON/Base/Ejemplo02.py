nombre = "Moad Mergoum"
edad = 18

print ("Mi nombre es " + nombre + " y mi edad es  " + str(edad) + " años")

nombre2 = "Alejandro Rivera"
edad2 = 19

print (f"Su nombre es {nombre2} y mi edad es {edad2} años")

nombre3 = "Leire Sanchez"
edad3 = 17

print ("Su nombre es ", nombre3, " y su edad es  ", edad3,  "años")
