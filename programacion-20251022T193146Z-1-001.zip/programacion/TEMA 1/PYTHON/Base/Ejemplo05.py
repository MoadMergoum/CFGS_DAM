precio = float(input("indica el precio de un producto: "))
cantidad = float(input("cantidad de unidades del producto: "))


precioTotal = precio*cantidad

print("El importe final es " + str(precioTotal))
