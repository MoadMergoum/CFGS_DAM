text = input("Introduce un texto de 10 caracteres: ").strip()
LongitudMinima = 10

if len(text) >= 10:
    print(f"El texto tiene los caracteres suficientes")
else:
    print("Caracteres no suficientes")
