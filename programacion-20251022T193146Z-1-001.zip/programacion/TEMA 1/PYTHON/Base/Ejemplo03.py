numero1 = 7
numero2 = 3.8

print("La suma de ambos numeros " + str(numero1+numero2))
