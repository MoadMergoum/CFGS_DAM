numero = int(input("introduce un numero entero: "))

if numero%2 ==0:
	print("El numero " + str(numero) +" es par")
else:
	print("El numero " + str(numero)+ " es impar")
