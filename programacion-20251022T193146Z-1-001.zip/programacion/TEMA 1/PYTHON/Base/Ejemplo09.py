cadena1= "coche"
cadena2= "coche"

if cadena1 == cadena2:
    print("SON IGUALES")
else:
    print("SON DISTINTOS")
