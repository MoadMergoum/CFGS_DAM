numero = int(input("Introduce tu edad"))

if numero >= 0 and numero < 18:
    print("Menor de edad ")
       
elif(numero >= 18 and numero < 65):
    print("Mayor de Edad")

elif( numero >= 65 and numero <= 130):
    print("Jubilado")
     
else:
    print("Edad erronea")

