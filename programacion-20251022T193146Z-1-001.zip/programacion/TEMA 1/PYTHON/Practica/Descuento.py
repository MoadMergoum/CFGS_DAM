precio = float(input("Introduce el precio del producto: "))
descuento = float(input("Introduce el porcentaje de descuento: "))

if descuento < 0 or descuento > 100:
    print("Descuento no válido")
    exit()

print("Continuar")


descuento_decimal = descuento / 100


monto_descuento = precio * descuento_decimal


precio_final = precio - monto_descuento

print("Precio final = " + str(precio_final))

