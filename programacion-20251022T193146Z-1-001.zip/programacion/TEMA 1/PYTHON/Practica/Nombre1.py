nombre1 = input("Introduce el nombre de la primera persona: ")
edad1 = int(input("Introduce la edad de la primera persona: "))
             
nombre2 = input("Introduce el nombre de la segunda persona: ")
edad2 = int(input("Introduce la edad de la segunda persona: "))

print(str(nombre1) + " tiene " + str(edad1) + " años")
print(str(nombre2) + " tiene " + str(edad2) + " años")

