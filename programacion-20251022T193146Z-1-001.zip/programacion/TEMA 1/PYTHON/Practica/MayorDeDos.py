numero1 = int(input("Introduce un numero entero "))
numero2 = int(input("Introduce otro numero entero "))	

if numero1 > numero2:
	print(str(numero1) + " es mayor que " + str(numero2))

elif(numero2 > numero1):
	print(str(numero2) + " es mayor que " + str(numero1))

else:
	print("Los dos son iguales")
		
	print("Fin del programa")

