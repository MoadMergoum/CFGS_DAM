numero = int(input("Introduce un número entero: "))

if (numero % 2 == 0) :
	print("El número " + str(numero) + " es par")
else :
	print("El número " + str(numero) + " es impar")

