numero1 = int(input("Introduce un numero : "))

numero2 = int(input("Introduce otro numero : "))

numero3 = int(input("Introduce otro numero : "))
	

if (numero1 > numero2 and numero1 > numero3) or (numero1 == numero2 and numero1 > numero3):
    print("El numero mayor es: " + str(numero1))
elif (numero2 > numero1 and numero2 > numero3) or (numero2 == numero1 and numero2 > numero3):
    print("El numero mayor es: " + str(numero2))
elif (numero1 == numero2 and numero1 == numero3 and numero3 == numero2 ):
	print("Todos son iguales 😀️")
else :
    print("El numero mayor es: " + str(numero3))



