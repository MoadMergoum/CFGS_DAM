Nombre1 = input("Introduce tu nombre ")
Apellidos1 = input("Introduce tus apellidos ")
DNI1 = input("Introduce tu DNI ")
CodigoPostal1 = input("Introduce tu CodigoPostal ")

Nombre2 = input("Introduce tu nombre ")
Apellidos2 = input("Introduce tus apellidos ")
DNI2 = input("Introduce tu DNI ")
CodigoPostal2 = input("Introduce tu CodigoPostal ")

Nombre3 = input("Introduce tu nombre ")
Apellidos3 = input("Introduce tus apellidos ")
DNI3 = input("Introduce tu DNI ")
CodigoPostal3 = input("Introduce tu CodigoPostal ")


print("Nombre completo: " + str(Nombre3) + str(Apellidos3))
print("DNI: " + str(DNI3))
print("Codigo Postal: " + str(CodigoPostal3))
    
print("Nombre completo: " + str(Nombre2) + str(Apellidos2))
print("DNI: " + str(DNI2))
print("Codigo Postal: " + str(CodigoPostal2))
    
print("Nombre completo: " + str(Nombre1) + str(Apellidos1))
print("DNI: " + str(DNI1))
print("Codigo Postal: " + str(CodigoPostal1))
    

