opcion = input("Escribe la operacion (suma|resta|multiplicacion|division): ")

if opcion.lower() != "suma" and opcion.lower() != "resta" and opcion.lower() != "multiplicacion" and opcion.lower() != "division":
    print("operacion no valida")
    exit()

print("continuar")

num1 = float(input("1º numero: "))
num2 = float(input("2º numero: "))

if opcion.lower() == "suma":
    resultado = num1 + num2
    print(str(num1) + " + " + str(num2) + " = " + str(resultado))

elif opcion.lower() == "multiplicacion":
    resultado = num1 * num2
    print(str(num1) + " * " + str(num2) + " = " + str(resultado))

elif opcion.lower() == "resta":
    resultado = num1 - num2
    print(str(num1) + " - " + str(num2) + " = " + str(resultado))

elif opcion.lower() == "division":
    if num2 == 0:
        print("no se puede dividir por cero")
    else:
        resultado = num1 / num2
        print(str(num1) + " / " + str(num2) + " = " + str(resultado))
