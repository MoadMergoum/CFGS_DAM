import java.util.Scanner;
public class TresUsuarios{
	public static void main(String[] args){
	
	Scanner teclado = new Scanner(System.in);



	System.out.println("Introduce tu nombre ");
	String Nombre1 = teclado.nextLine().trim();
	System.out.println("Introduce tus apellidos ");
	String Apellidos1 = teclado.nextLine().trim();
	System.out.println("Introduce tu DNI ");
	String DNI1 = teclado.nextLine().trim();
	System.out.println("Introduce tu CodigoPostal ");
	String CodigoPostal1 = teclado.nextLine().trim();

	System.out.println("Introduce tu nombre ");
	String Nombre2 = teclado.nextLine().trim();
	System.out.println("Introduce tus apellidos ");
	String Apellidos2 = teclado.nextLine().trim();
	System.out.println("Introduce tu DNI ");
	String DNI2 = teclado.nextLine().trim();
	System.out.println("Introduce tu CodigoPostal ");
	String CodigoPostal2 = teclado.nextLine().trim();

	System.out.println("Introduce tu nombre ");
	String Nombre3 = teclado.nextLine().trim();
	System.out.println("Introduce tus apellidos ");
	String Apellidos3 = teclado.nextLine().trim();
	System.out.println("Introduce tu DNI ");
	String DNI3 = teclado.nextLine().trim();
	System.out.println("Introduce tu CodigoPostal ");
	String CodigoPostal3 = teclado.nextLine().trim();


     System.out.println("Nombre completo: " + Nombre3 + Apellidos3);
     System.out.println("DNI: " + DNI3);
     System.out.println("Codigo Postal " + CodigoPostal3);
    
     System.out.println("Nombre completo: " + Nombre2 + Apellidos2);
     System.out.println("DNI: " + DNI2);
     System.out.println("Codigo Postal " + CodigoPostal2);

     System.out.println("Nombre completo: " + Nombre1 + Apellidos1);
     System.out.println("DNI: " + DNI1);
     System.out.println("Codigo Postal " + CodigoPostal1);
	}
}
