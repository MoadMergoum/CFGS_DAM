import java.util.Scanner;

public class MayorDeDos{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);
		
		System.out.print("Introduce un numero entero ");
		int numero1 = Integer.parseInt(teclado.nextLine());

		System.out.print("Introduce otro numero entero ");
		int numero2 = Integer.parseInt(teclado.nextLine()); 	

		if(numero1 > numero2){
			System.out.print(numero1 + " es mayor que " + numero2);
		} else if(numero2 > numero1){
		System.out.print(numero2 + " es mayor que " + numero1);
		}else {
		System.out.println("Los dos son iguales");
		}
		System.out.print("Fin del programa");
	}
}
