import java.util.Scanner;

public class MayorDeTres{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);
		
		System.out.print("Introduce un numero entero ");
		int numero1 = Integer.parseInt(teclado.nextLine());

		System.out.print("Introduce otro numero entero ");
		int numero2 = Integer.parseInt(teclado.nextLine()); 

		System.out.print("Introduce otro numero entero ");
		int numero3 = Integer.parseInt(teclado.nextLine()); 
	
		int Mayor;

        if ((numero1 > numero2 && numero1 > numero3) || (numero1 == numero2 && numero1 > numero3)) {
            Mayor = numero1;
        } else if ((numero2 > numero1 && numero2 > numero3) || (numero2 == numero1 && numero2 > numero3)) {
            Mayor = numero2;
	} else {
            Mayor = numero3;
        }

        System.out.println("El numero mayor es: " + Mayor);
    }
}
