import java.util.Scanner;

public class ComprobarEdad {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        
        System.out.print("Introduce tu edad: ");
        int numero = teclado.nextInt(); 

        if (numero < 18) {
            System.out.println("Menor de edad ");
        } 
		 else if(numero >= 18 && numero < 65){
            System.out.println("Mayor de Edad");
        }
		 else if( numero >= 65 && numero <= 130){
            System.out.println("Jubilado");
        }
		else {
            System.out.println("Edad erronea");
		}
    }
}
