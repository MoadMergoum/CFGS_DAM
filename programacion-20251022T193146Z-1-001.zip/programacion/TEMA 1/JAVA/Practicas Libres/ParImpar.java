import java.util.Scanner;

public class ParImpar {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
       
        
        System.out.print("Introduce un número entero: ");
        int numero = Integer.parseInt(teclado.nextLine()); 

        if (numero % 2 == 0) {
            System.out.println("El número " + numero + " es par");
        } else {
            System.out.println("El número " + numero + " es impar");
        }

    }
}
