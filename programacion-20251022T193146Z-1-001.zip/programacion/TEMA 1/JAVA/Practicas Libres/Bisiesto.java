import java.util.Scanner;

public class Bisiesto {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);

        
        System.out.print("Introduce un year entero: ");
        int year = teclado.nextInt(); 

        if (year % 4 == 0 && (year %100 != 0 || year%400 == 0)) {
            System.out.println("EL año es BISIESTO ");
        } else {
            System.out.println("EL año NO es BISIESTO ");
        }

    }
}
