import java.util.Scanner;

public class Nombre1 {

    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        
        String nombre1, nombre2;
        String edad1, edad2;
        
       
        System.out.print("Introduce el nombre de la primera persona: ");
        nombre1 = teclado.nextLine();
        System.out.print("Introduce la edad de la primera persona: ");
        edad1 = teclado.nextLine();
        
        
        System.out.print("Introduce el nombre de la segunda persona: ");
        nombre2 = teclado.nextLine();
        System.out.print("Introduce la edad de la segunda persona: ");
        edad2 = teclado.nextLine();
        
       
        System.out.println(nombre1 + " tiene " + edad1 + " años");
        System.out.println(nombre2 + " tiene " + edad2 + " años");
        
      
    }
}
