import java.util.Scanner;

public class Ejemplo9{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);
		System.out.print("Introduce un número entero: ");
		String numero1 =  teclado.nextLine();
		System.out.print("Introduce un número con decimales: ");
		String numero2 = teclado.nextLine();
		System.out.println("Numero 1: " + numero1);
		System.out.println("Numero 2: " + numero2);

		int num1 = Integer.parseInt(numero1);
		System.out.println("Numero 1 convertido a entero: " + num1);
		double num2 = Double.parseDouble(numero2);
		System.out.println("Numero 2 convertido a doble: " + num2);

	}
}
