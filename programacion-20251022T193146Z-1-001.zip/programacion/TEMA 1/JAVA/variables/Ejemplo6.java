import java.util.Scanner;

public class Ejemplo6{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce un número entero para dividir entre 2");

		int numero = teclado.nextInt();

		System.out.println("El número dividido entre 2 da como resultado: " + (numero/2));

	}

}
