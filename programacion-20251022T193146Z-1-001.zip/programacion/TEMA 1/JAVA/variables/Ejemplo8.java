public class Ejemplo8{
	public static void main(String[] args){

		int num1 = 100;
		double num2 = 2345.45;
		byte num3 = (byte) num1;
		System.out.println("num1 " + num1);
		System.out.println("num3 " + num3);

		 int num4 = (int) num2;
		System.out.println(num2 + " convertido a entero es " + num4);
	}



}
