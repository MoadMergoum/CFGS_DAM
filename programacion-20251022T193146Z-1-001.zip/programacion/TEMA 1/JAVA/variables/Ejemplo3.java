public class Ejemplo3{
	public static void main(String[] args){
		String nombre = "Antonio Molina";
		int numero1 = 5;
		int numero2 = 14;
		System.out.println("Mi nombre es " + nombre);
		int suma = numero1 + numero2;
		System.out.println("La suma de " + numero1 + " y " + numero2 +  " es igual a " + suma);
	}
}
