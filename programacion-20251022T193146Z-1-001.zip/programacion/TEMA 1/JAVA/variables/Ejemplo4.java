public class Ejemplo4{
	public static void main(String[] args){
		int numero1 = 4;
		int numero2 = 7;
		int numero3 = 2;
		int numero4 = 9;

		int suma = numero1 + numero3 + numero4;
		int resta = numero4 - numero2;
		int multiplicacion = numero1 * numero3;
		int division = (numero2 + numero4) / numero3;

		System.out.println("Operaciones matemáticas\n");
		System.out.println("Suma " + suma);
		System.out.println("Resta de " + numero4 + " menos " + numero2 + " es igual a " + resta);
		System.out.println("Multiplicacion " + multiplicacion);
		System.out.println("Division " + division); 
	}

}
