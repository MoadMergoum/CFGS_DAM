public class Ejemplo2{
	public static void main(String[] args){
		// variables en java
		int numero;
		numero = 12;
		System.out.println("El número es " + numero);
	}
}
