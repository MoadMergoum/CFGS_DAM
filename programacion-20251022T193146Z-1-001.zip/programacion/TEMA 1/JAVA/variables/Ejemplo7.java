import java.util.Scanner;

public class Ejemplo7{
	public static void main(String[] args){

		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce un numero con decimales para multiplicar por dos");
		double numero = teclado.nextDouble();
		System.out.println("El número " + numero + " multiplicado por 2 da " + (numero*2));
	}

}
