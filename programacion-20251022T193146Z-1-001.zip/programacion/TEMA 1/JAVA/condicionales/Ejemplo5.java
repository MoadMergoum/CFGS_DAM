import java.util.Scanner;

public class Ejemplo5{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);

			System.out.print("Introduce un numero entero: ");
			double numero = Double.parseDouble(teclado.nextLine());
			
			if(numero >=0 && numero <5){
				System.out.println("insuficiente, jsjsj que tonto ");			
 			} 

			else if(numero >= 5 && numero <6){
				System.out.println("Suficiente, por los pelos");
			}	

			else if(numero == 6){
            	System.out.println("Bien");
			}

			else if(numero >= 7 && numero <= 8){
            	System.out.println("Notable");
			}

			else if(numero >=8 && numero <=10){
            	System.out.println("Sobresaliente");
			}

     		else{ 
				System.out.println("Numero invalido");
			}


	}
}
