public class Ejemplo1{
	public static void main(String[] args){
		boolean valor1 = true;
		boolean valor2 = false;
		if(valor1){
			System.out.println("Se cumple la primera condición");

		}
		if(valor2){
			System.out.println("Se cumple la primera condición");
		}
		System.out.println("Fin de programa");
	}

}

