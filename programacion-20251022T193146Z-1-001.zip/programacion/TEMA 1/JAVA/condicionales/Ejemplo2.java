public class Ejemplo2{
	public static void main(String[] args){
		int numero = 16;
		System.out.println("Condición: " + (numero > 0));
		if(numero > 0){
			System.out.println("El número es positivo");

		}
		System.out.println("Fin de programa");
	}
}
