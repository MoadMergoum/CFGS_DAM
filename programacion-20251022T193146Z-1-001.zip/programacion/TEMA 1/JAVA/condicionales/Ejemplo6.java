import java.util.Scanner;

public class Ejemplo5{
	public static void main(String[] args){
	
		Scanner teclado = new Scanner(System.in);	

		System.out.println("Adivina la palabra");
		String texto = teclado.nextLine();
		final String PALABRA = "Messi";

		if(texto.equals(PALABRA)) {
			System.out.println("La palabra coincide");
		} else{
			System.out.println("La palabra no coincide");
		}

	}
}
