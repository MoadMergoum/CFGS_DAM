import java.util.Scanner;

public class Ejemplo4{
	public static void main(String[] args){
		Scanner teclado = new Scanner(System.in);

		System.out.print("Introduce un numero entero ");
		int numero = Integer.parseInt(teclado.nextLine());

		if(numero%2 == 0) { // comprobar si es par
			System.out.print("El numero " + numero + " es par");	
		}else {
			System.out.print("El numero " + numero + " es impar");
			}
	} 
}
