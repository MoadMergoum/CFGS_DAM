public class Ejemplo3{
	public static void main(String[] args){
		int numero = 8;
		// System.out.println("Condición: " + (numero > 0));
		if(numero+2 >= 10){
			System.out.println("El número es válido");

		}
		System.out.println("Fin de programa");
	}
}
