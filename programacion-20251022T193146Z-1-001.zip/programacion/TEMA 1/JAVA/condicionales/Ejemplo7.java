import java.util.Scanner;

public class Ejemplo7 {
    public static void main(String[] args){
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce un día de la semana para decirte qué hacer hoy: ");
        String dia = teclado.nextLine().trim();

        if(dia.equalsIgnoreCase("Lunes")){
            System.out.println("FOL, Digitalización, Sistemas, Programación");
        } else if(dia.equalsIgnoreCase("Martes")){
            System.out.println("Lenguaje de Marcas, Inglés, Sistemas");
        } else if(dia.equalsIgnoreCase("Miércoles")){
            System.out.println("FOL, Programación, Inglés");
        } else if(dia.equalsIgnoreCase("Jueves")){
            System.out.println("Bases de Datos y Entorno de Desarrollo");
        } else if(dia.equalsIgnoreCase("Viernes")){
            System.out.println("Programación, Bases de Datos y Lenguaje de Marcas");
        } else if(dia.equalsIgnoreCase("Sábado") || dia.equalsIgnoreCase("Domingo")){
            System.out.println("Día libre");
        } else {
            System.out.println("Día no válido");
        }

        
    }
}

